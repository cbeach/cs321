class testd26 {
  public static void main(String[] a) {
    new int[2] = 100;  // invalid lhs
  }
}
