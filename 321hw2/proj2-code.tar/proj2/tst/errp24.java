class testd24 {
  public static void main(String[] a) {
    int[] a = new int[5];
    a[2.5] = 2;	  // illegal '.' 
  }
}
