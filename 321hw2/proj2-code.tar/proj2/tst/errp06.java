// missing dummy arg in 'main'
class testd06 {
  public static void main() {
    int x;
  }
}
