// test array access
// (should print 1 2)
class test {
  public static void main(String[] a) {
    int[] a;
    a = new int[2];
    a[0] = 1;
    a[1] = 2;
    System.out.println(a[0]);
    System.out.println(a[1]);
  }
}
