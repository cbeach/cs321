// missing parens
class testd12 {
  public static void main(String[] a) {
    while true
      i = 1;
  }
}
