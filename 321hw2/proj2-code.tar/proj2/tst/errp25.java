class testd25 {
  public static void main(String[] a) {
    int[] a = new int[true];  // array index is not int
  }
}
