class prog {
  public static void main(String[] args) {
    int[] a = new int[2];
    int i = 0;
    while (i<2) {
      System.out.println(a[i]);
      i = i+1;
    }
  }
}
