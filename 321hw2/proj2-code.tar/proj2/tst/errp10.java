// wrong syntax at []
class testd10 {
  public static void main(String[] a) {
    int a[];
  }
}
