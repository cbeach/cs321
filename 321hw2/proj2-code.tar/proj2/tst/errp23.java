class testd23 {
  public static void main(String[] a) {
    this = 1;  // invalid lhs
  }
}
