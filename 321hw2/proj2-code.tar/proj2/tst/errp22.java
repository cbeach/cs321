class testd22 {
  public static void main(String[] a) {
    int x;
    x = (1).x();  // (1) is not a valid lvalue
  }
}
