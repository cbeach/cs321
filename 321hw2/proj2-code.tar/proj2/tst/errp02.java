// missing keyword 'static'
class testd02 {
  public void main(String[] a) {
    int x;
  }
}
