// missing keyword 'class'
testd01 {
  public static void main(String[] a) {
    System.out.println(x);  
  }
}
