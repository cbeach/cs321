// missing '{'
class testd04 
  public static void main(String[] a) {
  }
}
