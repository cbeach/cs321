// wrong syntax at the second [
class testd14 {
  public static void main(String[] a) {
    i[1][2] = 3;
  }

}
