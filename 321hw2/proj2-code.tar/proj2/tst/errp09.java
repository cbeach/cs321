// wrong assignment symbol
class testd09 {
  public static void main(String[] a) {
    x == 100;
  }
}
